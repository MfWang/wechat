 //app.js
var util = require('utils/util')
App({
  onLaunch: function() {

    var that = this;

    new Promise(function (res, rej) {
      console.log(Date.now() + " start setTimeout 1");
    })
      .then(that.loginWX2())
      .then(that.getWXUserInfo2())
    //   .then(that.getBMToken())
    //   .then(that.updateBMUser())
    //   .then(that.getBMUserInfo())
    // .then(function () {
    //   console.log(Date.now() + " timeout 2 call back");
    // });
    // util.wxPromisify(that.loginWX2())
    // 登录
    // this.loginWX();
  },
  getWXSetting: function () {
    console.log('getWXSetting start')
    var that = this;
    wx.getSetting({
      success(res) {
        console.log('getWXSetting success')
        if (!res.authSetting['scope.userInfo']) {
          wx.authorize({
            scope: 'scope.userInfo',
            success() {
              that.getWXUserInfo();
            },
            fail: function (res) {
              that.openWXSetting()
            }
          })
        }
      },
      fail: function (res) {
        console.log('接口调用失败')
      }
    })
  },
  openWXSetting: function () {
    var that = this;
    wx.openSetting({
      success: (res) => {
        console.log(66)
      },
      fail: (res) => {
        console.log(res)
      },
      complete: (res) => {
        console.log(0)
      }
    })
  },
  loginWX2: function () {
    var that = this;
    return new Promise(function (res, rej) {
      console.log('login start')
      wx.login({
        success: res => {
          if (res.code) {
            console.log('login success')
            // 发送 res.code 到后台换取 openId, sessionKey, unionId
            that.globalData.code = res.code
          } else {
            console.log('login fail')
            wx.showModal({
              title: '获取用户登录态失败',
              content: '重新登录？',
              success: function (res) {
                if (res.confirm) {
                  that.loginWX()
                } else if (res.cancel) {
                }
              }
            })
          }
        }
      })
    });
  },
  getWXUserInfo2: function () {
    var that = this;
    return new Promise(function (res, rej) {
      console.log('getWXUserInfo start')
      if (that.globalData.userInfo) {
        typeof cb == "function" && cb(this.globalData.userInfo)
      } else {
        //调用登录接口
        wx.getUserInfo({
          withCredentials: false,
          success: function (res) {
            console.log('getWXUserInfo success')
            that.globalData.userInfo = res.userInfo
          },
          fail: function (res) {
            console.log('getWXUserInfo fail')
            console.log(res)
          }
        })
      }
    });
  },
  getBMToken2: function () {
    var that = this;
    return new Promise(function (res, rej) {
      console.log('getBMToken start')
      wx.request({
        url: `${that.globalData.bongmiAPI}/wechat_mp/access_token`,
        data: {
          app_id: that.globalData.appid,
          code: that.globalData.code
        },
        success: function (res) {
          console.log('getBMToken success')
          that.globalData.bmUser = res.data;
        }
      })
    });
  },
  updateBMUser2: function () {
    var that = this;
    return new Promise(function (res, rej) {
      console.log('updateBMUser start')
      wx.request({
        url: `${that.globalData.bongmiAPI}/user/${that.globalData.bmUser.userId}?access_token=${that.globalData.bmUser.accessToken}`,
        data: {
          id: that.globalData.bmUser.userId,
          nickname: that.globalData.userInfo.nickName,
          gender: that.globalData.userInfo.gender == 2 ? 'Female' : 'Male'
        },
        header: {
          authorization: 'Lollypop-Weixin-Mini-Program'
        },
        method: 'PUT',
        success: function (res) {
          console.log('updateBMUser success')
        }
      })
    });
    
  },
  getBMUserInfo2: function () {
    var that = this;
    return new Promise(function (res, rej) {
      console.log('getBMUserInfo start')
      wx.request({
        url: `${that.globalData.bongmiAPI}/user/${that.globalData.bmUser.userId}`,
        data: {
          access_token: that.globalData.bmUser.accessToken
        },
        header: {
          authorization: 'Lollypop-Weixin-Mini-Program'
        },
        success: function (res) {
          console.log('getBMUserInfo success')
          that.globalData.bmUser = Object.assign(that.globalData.bmUser, res.data);
        }
      })
    });
    
  },
  loginWX: function () {
    var that = this;
    console.log('login start')
    wx.login({
      success: res => {
        if (res.code) {
          console.log('login success')
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          that.globalData.code = res.code
          that.getWXUserInfo();
        } else {
          console.log('login fail')
          wx.showModal({
            title: '获取用户登录态失败',
            content: '重新登录？',
            success: function (res) {
              if (res.confirm) {
                that.loginWX()
              } else if (res.cancel) {
              }
            }
          })
        }
      }
    })
  },
  getWXUserInfo: function () {
    var that = this;
    console.log('getWXUserInfo start')
    if (that.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.getUserInfo({
        withCredentials: false,
        success: function (res) {
          console.log('getWXUserInfo success')
          that.globalData.userInfo = res.userInfo
          that.getBMToken();
        },
        fail: function (res) {
          console.log('getWXUserInfo fail')
          console.log(res)
        }
      })
    }
  },
  getBMToken: function () {
    var that = this;
    console.log('getBMToken start')
    wx.request({
      url: `${that.globalData.bongmiAPI}/wechat_mp/access_token`,
      data: {
        app_id: that.globalData.appid,
        code: that.globalData.code
      },
      success: function (res) {
        console.log('getBMToken success')
        that.globalData.bmUser = res.data;
        that.updateBMUser();
      }
    })
  },
  updateBMUser: function () {
    var that = this;
    console.log('updateBMUser start')
    wx.request({
      url: `${that.globalData.bongmiAPI}/user/${that.globalData.bmUser.userId}?access_token=${that.globalData.bmUser.accessToken}`,
      data: {
        id: that.globalData.bmUser.userId,
        nickname: that.globalData.userInfo.nickName,
        gender: that.globalData.userInfo.gender == 2 ? 'Female' : 'Male'
      },
      header: {
        authorization: 'Lollypop-Weixin-Mini-Program'
      },
      method: 'PUT',
      success: function (res) {
        console.log('updateBMUser success')
        that.getBMUserInfo();
      }
    })
  },
  getBMUserInfo: function () {
    var that = this;
    console.log('getBMUserInfo start')
    wx.request({
      url: `${that.globalData.bongmiAPI}/user/${that.globalData.bmUser.userId}`,
      data: {
        access_token: that.globalData.bmUser.accessToken
      },
      header: {
        authorization: 'Lollypop-Weixin-Mini-Program'
      },
      success: function (res) {
        console.log('getBMUserInfo success')
        that.globalData.bmUser = Object.assign(that.globalData.bmUser, res.data);
      }
    })
  },
  takePhoto: function () {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['camera'],
      success: function (res) {
        that.globalData.pictureLocal = res.tempFilePaths[0]
        that.getQiniuToken(1);
      }
    });
  },
  getQiniuToken: function (pictureType) {
    const that = this;
    const bmUser = that.globalData.bmUser;
    wx.request({
      url: `${that.globalData.bongmiAPI}/user/${bmUser.userId}/upload_info`,
      data: {
        type: 2,
        access_token: bmUser.accessToken
      },
      header: {
        authorization: 'Lollypop-Weixin-Mini-Program'
      },
      success: function (res) {
        that.globalData.uploadInfo = res.data
        that.uploadPhoto(pictureType);
      }
    })
  },
  uploadPhoto: function (pictureType) {
    const that = this;
    const bmUser = that.globalData.bmUser;
    wx.uploadFile({
      url: `${that.globalData.qiniuUploadUrl}`,
      filePath: pictureType == 1 ? that.globalData.pictureLocal : that.globalData.tailorLocal,
      name: 'file',
      formData: {
        token: that.globalData.uploadInfo.uploadToken,
        key: that.globalData.uploadInfo.fileName
      },
      success: function (res) {
        const data = JSON.parse(res.data);
        if (pictureType == 1) {
          that.globalData.pictureOnline = data.key;
          wx.redirectTo({
            url: '/pages/cutInside/cutInside',
            success: function (res) {
              console.log('success')
              // success
            },
            fail: function (res) {
              console.log(res)
              // fail
            },
            complete: function () {
              console.log('complete')
              // complete
            }
          })
        } else {
          that.globalData.tailorOnline = data.key;
          wx.redirectTo({
            url: '/pages/result/result',
            success: function (res) {
              console.log('success')
              // success
            },
            fail: function (res) {
              console.log(res)
              // fail
            },
            complete: function () {
              console.log('complete')
              // complete
            }
          })
        }
      }
    })
  },
  globalData: {
    bongmiAPI: 'https://api-staging.bongmi.com/v1',
    appid: 'wx7e71d8c807fc0f58',
    secret: 'a76c9f9638f02c9b19d048a6fccefca1',
    code: null,
    bmUser: null,
    userInfo: null,
    pictureLocal: null,
    pictureOnline: null,
    tailorLocal: null,
    tailorOnline: null,
    result: null,
    qiniuUploadUrl: 'https://up.qbox.me',
    downloadUrl: 'https://img.bongmi.com',
    https: true,
    uploadInfo: null
  }
})
